/**
\file main_widget.cpp
\brief contains the Buttons and the labels of the main page that loads
at the beginning of the project

*
This class inherits from QWidget and it contains 3 buttons are History,Game,
and Account

\author Sami Kanafani & Mohamad Ali Mahaidli

*/

#include "main_widget.h"

/**
\breif Constructor of the entrance class
\param parent of type QWidget

*
In this function, all the buttons of the entrance class are created, siganls are defined
and connected to the buttons, and the setLayout function is called

*/

main_widget::main_widget(QWidget *parent) :
    QWidget(parent)
{
    current_game = "";
    Account = new QPushButton("Account");
    QObject::connect(Account,SIGNAL(clicked()),this,SLOT(account_click()));

    History = new QPushButton("History");
    //History->setEnabled(false);
    QObject::connect(History,SIGNAL(clicked()),this,SLOT(history_click()));

    Games = new QPushButton("Games");
    //Game->setEnabled(false);
    QObject::connect(Games,SIGNAL(clicked()),this,SLOT(games_click()));

    Bacck = new QPushButton("Back");
    //Bacck->setEnabled(false);
    QObject::connect(Bacck,SIGNAL(clicked()),this,SLOT(back_click()));

    set_horizontal_layout();
    set_stacked_layout();
    set_vertical_layout();
    setLayout(VLayout);
}
/**
\brief sets stacked layout
*
In this function, the windows of the program are added to the stacked layout

*/
void main_widget::set_stacked_layout(){
    SLayout = new QStackedLayout();

    hello = new QLabel("Welcome to 435L Project!");
    SLayout->addWidget(hello);

    account = new account_widget();
    SLayout->addWidget(account);

    history = new history_widget();
    SLayout->addWidget(history);

    games_list = new games_list_widget();
    SLayout->addWidget(games_list);

    QObject::connect(games_list->game_1_btn, SIGNAL(clicked()), this, SLOT(enter_play_menu()));
    QObject::connect(games_list->game_2_btn, SIGNAL(clicked()), this, SLOT(enter_play_menu()));
    QObject::connect(games_list->game_3_btn, SIGNAL(clicked()), this, SLOT(enter_play_menu()));
    QObject::connect(games_list->game_4_btn, SIGNAL(clicked()), this, SLOT(enter_play_menu()));

    //QObject::connect(SLayout, SIGNAL(currentChanged (int)), this, SLOT(slayout_change()));
}
/**
\brief sets the play menu
*
In this function, the play menu is created and set

*/
void main_widget::enter_play_menu()
{
    QPushButton *senderObj = (QPushButton*)sender();
    current_game = senderObj->text();
    play_menu = new play_menu_widget(current_game);

    //connect the buttons
    QObject::connect(play_menu->new_btn, SIGNAL(clicked()), this, SLOT(enter_levels_menu()));

    /*
    Not implemented yet
    QObject::connect(play_menu->resume_btn, SIGNAL(clicked()), this, enter_resume_levels_menu());
    QObject::connect(play_menu->instructions_btn, SIGNAL(clicked()), this, show_instructions());
    */

    SLayout->addWidget(play_menu);
    SLayout->setCurrentWidget(play_menu);
}
/**
\brief sets the levels menu
*
In this function, the levels menu is created and set

*/
void main_widget::enter_levels_menu()
{
    levels_list = new levels_list_widget();
    QObject::connect(levels_list->level_1_btn, SIGNAL(clicked()), this, SLOT(launch_new_game()));
    QObject::connect(levels_list->level_2_btn, SIGNAL(clicked()), this, SLOT(launch_new_game()));
    QObject::connect(levels_list->level_3_btn, SIGNAL(clicked()), this, SLOT(launch_new_game()));

    SLayout->addWidget(levels_list);
    SLayout->setCurrentWidget(levels_list);
}

/**
\brief creates the game widget
*
In this function, the game widget is created and shown and the main window is hidden

*/
void main_widget::launch_new_game()
{
    QPushButton *senderObj = (QPushButton*)sender();
    QString level = senderObj->text();
    if (level == "Level I")
        current_game_level = 1;
    if (level == "Level II")
        current_game_level = 2;
    if (level == "Level III")
        current_game_level = 3;

    if (current_game == "Balloon Shooting")
    {
        game_1 = new game_1_widget(current_game_level);

        connect(game_1, SIGNAL(repeat_1(int)), this, SLOT(repeat_game_1(int)));
        connect(game_1, SIGNAL(exit_1()), this, SLOT(exit_game_1()));

        game_1->show();
        this->hide();
    }

    if (current_game == "Escape Hangman")
    {

        game_2 = new lev2game(current_game_level);


        connect(game_2, SIGNAL(repeat_2(int)), this, SLOT(repeat_game_2(int)));
        connect(game_2, SIGNAL(exit_2()), this, SLOT(exit_game_2()));

        game_2->show();
        this->hide();

    }

    if (current_game == "Escape Maze")
    {

        game_3 = new lev3game(current_game_level);


        connect(game_3, SIGNAL(repeat_3(int)), this, SLOT(repeat_game_3(int)));
        connect(game_3, SIGNAL(exit_3()), this, SLOT(exit_game_3()));

        game_3->show();
        this->hide();

    }
    if(current_game == "Scrabble"){
        game_4 = new lev4game(current_game_level);

        game_4->show();
        this->hide();
    }
}
/**
\brief handles the exit signal of game 3
*
In this function, the game window is closed and the main menu is shown

*/

void main_widget::exit_game_3()
{
    game_3->close();
    delete game_3;

    current_game_level = 0;
    current_game = "";

    SLayout->setCurrentWidget(hello);
    this->show();
}
/**
\brief handles the repear signal of game 3
*
In this function, the game window is recreated

*/

void main_widget::repeat_game_3(int level)
{
    game_3->close();
    delete game_3;

    current_game_level = level;
    game_3 = new lev3game(level);

    connect(game_3, SIGNAL(repeat_3(int)), this, SLOT(repeat_game_3(int)));
    connect(game_3, SIGNAL(exit_3()), this, SLOT(exit_game_3()));

    game_3->show();
}
/**
\brief handles the exit signal of game 2
*
In this function, the game window is closed and the main menu is shown

*/

void main_widget::exit_game_2()
{
    game_2->close();
    delete game_2;

    current_game_level = 0;
    current_game = "";

    SLayout->setCurrentWidget(hello);
    this->show();
}
/**
\brief handles the repear signal of game 2
*
In this function, the game window is recreated

*/

void main_widget::repeat_game_2(int level)
{
    game_2->close();
    delete game_2;

    current_game_level = level;
    game_2 = new lev2game(level);

    connect(game_2, SIGNAL(repeat_2(int)), this, SLOT(repeat_game_2(int)));
    connect(game_2, SIGNAL(exit_2()), this, SLOT(exit_game_2()));

    game_2->show();
}
/**
\brief handles the exit signal of game 1
*
In this function, the game window is closed and the main menu is shown

*/
void main_widget::exit_game_1()
{
    game_1->close();
    delete game_1;

    current_game_level = 0;
    current_game = "";

    SLayout->setCurrentWidget(hello);
    this->show();
}
/**
\brief handles the repear signal of game 1
*
In this function, the game window is recreated

*/
void main_widget::repeat_game_1(int level)
{
    game_1->close();
    delete game_1;

    current_game_level = level;
    game_1 = new game_1_widget(level);

    connect(game_1, SIGNAL(repeat_1(int)), this, SLOT(repeat_game_1(int)));
    connect(game_1, SIGNAL(exit_1()), this, SLOT(exit_game_1()));

    game_1->show();
}

/**/
/**
\brief sets horizontal layout
*
in this function, the buttons and the elements
of the class are added to the horizontal layout

*/
void main_widget::set_horizontal_layout(){
    HLayout = new QHBoxLayout();
    HLayout->addWidget(Account);
    HLayout->addWidget(History);
    HLayout->addWidget(Games);
    HLayout->addWidget(Bacck);
}

/**
\brief sets vertical layout
*
in this function, the layersof the class are
added to the vertical layout

*/
void main_widget::set_vertical_layout(){
    VLayout = new QVBoxLayout();
    VLayout->addLayout(HLayout);
    VLayout->addLayout(SLayout);
}

/**
\brief slot when history button is clicked
*
This slot is called when the history button issues a signal, and the history menu is set
*/
void main_widget::history_click(){
    SLayout->setCurrentWidget(history);
    Bacck->setEnabled(true);
}

/**
\brief slot when account button is clicked
*
This slot is called when the account button issues a signal, and the account menu is set
*/
void main_widget::account_click(){
    SLayout->setCurrentWidget(account);
}
/**
\brief slot when games button is clicked
*
This slot is called when the games button issues a signal, and the games menu is set
*/
void main_widget::games_click(){
    SLayout->setCurrentWidget(games_list);
}
/**/
/**
\brief slot when back button is clicked
*
This slot is called when the back button issues a signal, it is not implemented yet
*/
void main_widget::back_click(){
    //SLayout->setCurrentIndex(previous_window_index);
}

void main_widget::slayout_change(){
   // update the back button based on behavior
   // the back button has not been implemented yet
}

